package web.saborgourmet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaborgourmetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaborgourmetApplication.class, args);
	}

}
