package web.saborgourmet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaborgourmetApplicationTests {

	@Test
	void contextLoads() {
	}

}
